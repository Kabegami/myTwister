package bd;

public class DBStatic {
	public static String mysql_host = "li328.lip6.fr:33306";
	public static String mysql_db = "gr3_becir";
	public static String mysql_username = "gr3_becir";
	public static String mysql_password = "becir";
	public static boolean mysql_pooling = false;
	
	public static String mongo_host = "li328.lip6.fr";
	public static int mongo_port = 27130;
	public static String mongo_db = "gr3_becir";

}
